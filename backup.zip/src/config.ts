// Set this to true to use mock data, false to use real API data
export const USE_MOCK_DATA = true; 